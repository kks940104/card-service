package org.anonymous;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CardServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
